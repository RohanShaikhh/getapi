const express = require("express");
require("dotenv").config()
const cors = require("cors");
const app = express();
const port = 5000;
const connection = require('./db')
const jwt = require('jsonwebtoken');
const {ethers,JsonRpcProvider , formatEther, parseUnits, isAddress, ContractTransactionResponse, InfuraProvider} = require("ethers");
app.use(express.json());

app.use(cors())
// app.use(
//   express.urlencoded({
//     extended: true,
//   })
// );
// app.use(cors({ origin: "http://localhost:3000", optionsSuccessStatus: 200 }));

const SECRET_KEY = process.env.SECRET_KEY

app.get("/allrecords", async function (req, res) {
  res.setHeader("Content-Type", "application/json");
  connection.query(
    `SELECT record FROM transactionrecord`,
    function (err, result) {
      if (err) {throw err;}
      else{
        var data = {}
        for(let i = 0; i < result.length; i++){
          var value = jwt.verify(result[i].record,SECRET_KEY)
          data[i] = value
        }
      //   const data = jwt.verify(result[1].record , SECRET_KEY)
      // // const decode = jwt.verify(result[0] , SECRET_KEY )
      res.send(data);
    }
    }
  );
});


// app.post("/insertrecord", function (req, res) {
//   res.setHeader("Content-Type", "application/json");
//   //  res.send("100");
//   let record = {
//     txHash: req.body.txHash,
//     timestamp: req.body.timestamp,
//     amount: req.body.amount,
//     from: req.body.from,
//     to : req.body.to,
//     tokenName : req.body.tokenName
//   };

//   const convert = jwt.sign(record,SECRET_KEY)

//   let sql = `insert into transactionrecord SET record = '${convert}'`;
//   console.log("successfully updated");
//   connection.query(sql, record, (err, result) => {
//     if (err) throw err;
//     res.end();
//     console.log("ending");
//   });
// });





app.listen(port, () => {
    console.log(`Example app listening at http://localhost:${port}`);
  });
